using UnityEngine;

public class Restart : MonoBehaviour
{
	private void Start()
	{
	}
}
